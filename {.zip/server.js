// server.js — Servient WoT para o wearable "patient001"
// Expõe TODAS as propriedades / ações / eventos da TD_Unified.json,
// com handlers simulados, via HTTP (e opcionalmente MQTT).
//
// Como correr:
//   npm install @node-wot/core @node-wot/binding-http
//   # opcional MQTT:   npm install @node-wot/binding-mqtt  (e ter Mosquitto em mqtt://localhost:1883)
//   node server.js

const { Servient } = require("@node-wot/core");
const { HttpServer } = require("@node-wot/binding-http");
// const { MqttBrokerServer } = require("@node-wot/binding-mqtt"); // ← descomenta se tiveres broker

const servient = new Servient();
servient.addServer(new HttpServer({ port: 8080 }));

// Descomenta as próximas 3 linhas depois de instalar @node-wot/binding-mqtt
// e de ter o Mosquitto a correr em localhost:1883 :
// servient.addServer(new MqttBrokerServer({
//   uri: "mqtt://localhost:1883"
// }));

servient.start().then(async (WoT) => {

  // --- Estado interno simulado -----------------------------------------
  const state = {
    heartRate: 70,
    spO2: 98.0,
    bodyTemperature: 36.5,
    ambientTemperature: 22.0,
    samplingIntervalMs: 5000,
    emissivity: 0.98,
    thresholds: {
      heartRate:       { min: 50,  max: 150 },
      spO2:            { min: 90 },
      bodyTemperature: { min: 35.0, max: 38.0 }
    },
    vibrationActive: false,
    lastVibrationAt: null,
    connectionStatus: "online",
    batteryLevel: 87,
    patient: { patientId: "patient001", displayName: "Paciente 001", age: 65 }
  };

  // --- Produz a Thing ---------------------------------------------------
  // NOTA: não passamos os "forms" do TD_Unified.json — o node-wot gera
  // forms corretos (com os URIs reais dos servers ativos).
  const thing = await WoT.produce({
    "@context": [
      "https://www.w3.org/2022/wot/td/v1.1",
      { "healthiot": "https://w3id.org/iotschema/health#" }
    ],
    "@type": ["Thing", "healthiot:WearableHealthMonitor"],
    id: "urn:dev:wot:health-monitor:wearable:patient001",
    title: "patient001",
    description: "Dispositivo vestível ESP32 (MAX30100 + MLX90614 + vibração).",
    securityDefinitions: { nosec_sc: { scheme: "nosec" } },
    security: ["nosec_sc"],

    properties: {
      heartRate:          { type: "integer", unit: "bpm",     minimum: 30, maximum: 220, readOnly: true,  observable: true  },
      spO2:               { type: "number",  unit: "%",       minimum: 0,  maximum: 100, readOnly: true,  observable: true  },
      bodyTemperature:    { type: "number",  unit: "Celsius", minimum: 20, maximum: 45,  readOnly: true,  observable: true  },
      ambientTemperature: { type: "number",  unit: "Celsius",                              readOnly: true                     },
      samplingIntervalMs: { type: "integer", minimum: 1000, maximum: 60000                                                  },
      emissivity:         { type: "number",  minimum: 0.1,  maximum: 1.0                                                    },
      thresholds:         { type: "object", observable: true                                                                },
      vibrationActive:    { type: "boolean", readOnly: true,  observable: true                                              },
      lastVibrationAt:    { type: "string",  format: "date-time", readOnly: true                                            },
      connectionStatus:   { type: "string",  enum: ["online","offline","reconnecting"], readOnly: true, observable: true    },
      batteryLevel:       { type: "integer", unit: "%", minimum: 0, maximum: 100, readOnly: true, observable: true          },
      patient:            { type: "object",  readOnly: true                                                                 }
    },

    actions: {
      calibrate:         { input:  { type: "object" }, output: { type: "object" } },
      activateVibration: {
        input: {
          type: "object",
          required: ["duration_ms", "pattern"],
          properties: {
            duration_ms: { type: "integer", minimum: 100, maximum: 10000 },
            pattern:     { type: "string",  enum: ["short","long","sos"] },
            intensity:   { type: "integer", minimum: 0, maximum: 255 }
          }
        },
        output: { type: "object" }
      },
      stopVibration:     { },
      registerDevice:    { input: { type: "object" } }
    },

    events: {
      criticalHealthAlert:  { data: { type: "object" } },
      vibrationCompleted:   { data: { type: "object" } },
      deviceStatusChanged:  { data: { type: "object" } }
    }
  });

  // --- Handlers das propriedades ---------------------------------------
  const readOnlyKeys = [
    "heartRate", "spO2", "bodyTemperature", "ambientTemperature",
    "vibrationActive", "lastVibrationAt", "connectionStatus",
    "batteryLevel", "patient"
  ];
  const writableKeys = ["samplingIntervalMs", "emissivity", "thresholds"];

  for (const key of readOnlyKeys) {
    thing.setPropertyReadHandler(key, async () => state[key]);
  }
  for (const key of writableKeys) {
    thing.setPropertyReadHandler(key, async () => state[key]);
    thing.setPropertyWriteHandler(key, async (value) => {
      state[key] = await value.value();
      console.log(`✏️  ${key} =`, state[key]);
    });
  }

  // --- Handlers das ações ----------------------------------------------
  thing.setActionHandler("calibrate", async (params) => {
    const input = params ? await params.value() : {};
    console.log("🛠  calibrate:", input);
    return { success: true, durationMs: (input?.mode === "full") ? 5000 : 1200 };
  });

  thing.setActionHandler("activateVibration", async (params) => {
    const input = await params.value();
    state.vibrationActive = true;
    state.lastVibrationAt = new Date().toISOString();
    console.log("📳 vibração ON:", input);

    setTimeout(() => {
      state.vibrationActive = false;
      thing.emitEvent("vibrationCompleted", {
        durationMs: input.duration_ms,
        pattern:    input.pattern,
        timestamp:  new Date().toISOString()
      });
      console.log("📳 vibração OFF");
    }, input.duration_ms);

    return { success: true, startedAt: state.lastVibrationAt };
  });

  thing.setActionHandler("stopVibration", async () => {
    state.vibrationActive = false;
    console.log("🛑 stopVibration");
  });

  thing.setActionHandler("registerDevice", async (params) => {
    const input = params ? await params.value() : {};
    console.log("📒 registerDevice em:", input?.directoryUrl || "(default)");
  });

  // --- Simulação periódica dos sensores --------------------------------
  setInterval(() => {
    state.heartRate       = Math.floor(60 + Math.random() * 40);
    state.spO2            = +(94 + Math.random() * 5).toFixed(1);
    state.bodyTemperature = +(36 + Math.random() * 1.5).toFixed(2);

    // exemplo de alerta quando o BPM sai do limiar
    const { min, max } = state.thresholds.heartRate;
    if (state.heartRate < min || state.heartRate > max) {
      thing.emitEvent("criticalHealthAlert", {
        source: "heartRate",
        value: state.heartRate,
        threshold: state.thresholds.heartRate,
        severity: state.heartRate > max + 30 ? "red" : "yellow",
        patientId: state.patient.patientId,
        timestamp: new Date().toISOString()
      });
    }

    console.log("💓 BPM:", state.heartRate,
                "| SpO2:", state.spO2,
                "| Temp:", state.bodyTemperature);
  }, 2000);

  await thing.expose();

  console.log("\n🚀 Servient ativo:");
  console.log("   • TD          → http://localhost:8080/patient001");
  console.log("   • heartRate   → http://localhost:8080/patient001/properties/heartRate");
  console.log("   • spO2        → http://localhost:8080/patient001/properties/spO2");
  console.log("   • bodyTemp    → http://localhost:8080/patient001/properties/bodyTemperature");
  console.log("   • vibrar      → POST http://localhost:8080/patient001/actions/activateVibration");
});